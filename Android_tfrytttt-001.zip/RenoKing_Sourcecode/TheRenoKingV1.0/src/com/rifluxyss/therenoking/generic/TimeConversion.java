package com.rifluxyss.therenoking.generic;

public class TimeConversion {	

	 public static final long ONE_WEEK = 604800000L;
	 public static final long ONE_DAY = 86400000L;
	 public static final long ONE_HOUR = 3600000L;
	 public static final long ONE_MINUTE = 60000L;
	 public static final long ONE_SECOND = 1000L;
}
