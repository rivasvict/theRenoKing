package com.rifluxyss.therenoking.generic;

public class Generic {	

	 public static boolean PROSPECTS_LOAD = false;
	 public static boolean LIVE_WEBSERVICE = true;
}