package com.rifluxyss.therenoking.utils;

public class ResultHandler {
	
	 public static final int ADD_PROSPECTS_RESULT = 1001;
	 public static final int AUTH_RESULT = 1002;
	 public static final int COMMENT_RESULT = 1003;
	 public static final int ADD_PROSPECTS_ADDRESS = 333;	 

}
