package com.rifluxyss.therenoking.utils;

public class EnumHandler {
	
	 public static final int SYNC_PROSPECTS = 101; // splash activity
	 public static final int FILTER_PROSPECTS = 102; 
	 public static final int SET_REMINDER = 103;
	 public static final int SET_ESTIMATE = 104;
	 public static final int SET_PROJECT = 105;
	 public static final int SHOW_CAMPAIGN = 106;
	 public static final int PROSPECT_DID_NOT_SHOW = 107;
	 public static final int PROSPECT_DETAIL = 108;
}
