package com.rifluxyss.therenoking.beans;

public class NotesData {	
	public String notes;
	public String date;
}
