package com.rifluxyss.therenoking.beans;


public class ProspectData {	
	public String name;
	public String stage;
	public String status;
	public String reminder;
}
